java -jar libs/teamcat-agent-2.3.1.jar
